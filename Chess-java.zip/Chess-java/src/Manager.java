
public class Manager {

	public static void main(String[] args) {
		
		Frame frame = new Frame();
		MainFrame mainFrame = new MainFrame(frame);
		
		
	}

}
